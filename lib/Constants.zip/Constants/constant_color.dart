import 'dart:ui';

Color babyBlue = const Color.fromARGB(255, 185, 223, 241);
Color mainColor = const Color.fromARGB(255, 255, 249, 234);
Color videoColor = const Color.fromARGB(255,236, 223, 208);
Color buttonsLabel = const Color.fromARGB(255, 241, 229, 218);
Color lightOlive = const Color.fromARGB(255, 197, 183, 159);
Color orange = const Color.fromARGB(255, 198,149,65);
Color darkOlive = const  Color.fromARGB(255, 85,76,42);